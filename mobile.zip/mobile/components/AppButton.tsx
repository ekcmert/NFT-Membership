import React from 'react'
import { View, Text } from 'react-native'
const AppButton = () => {
	return (
		<View>
			<Text />
		</View>
	)
}
export default AppButton

