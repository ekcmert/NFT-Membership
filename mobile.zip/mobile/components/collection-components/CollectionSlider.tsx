import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';

// This is the collection slider that will be used for homescreen-searchscreen

export default function CollectionSlider({ path }: { path: string }) {
  return (
    <View>
      {/* Insert your code */}
    </View>
  );
}



const styles = StyleSheet.create({
  styleExample: {
    alignItems: 'center',
    marginHorizontal: 50,
  },
  
});
