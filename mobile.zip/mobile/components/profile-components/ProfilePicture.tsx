import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';

// This is the profile picture component that will be used for profiles

export default function ProfilePicture({ path }: { path: string }) {
  return (
    <View>
      {/* Insert your code */}
    </View>
  );
}



const styles = StyleSheet.create({
  styleExample: {
    alignItems: 'center',
    marginHorizontal: 50,
  },
  
});
