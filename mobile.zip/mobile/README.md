Artizan is a NFT Marketplace project done by:

- Ahmet Mihça Aydın
- Sadi Gülbey

This is the mobile platform part of Artizan.
