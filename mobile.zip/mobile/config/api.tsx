
const API_URL = "http://188.40.16.170:56030/";
const TIMEOUT = 1000;
const BACKEND = "http://10.50.116.36:3001/api/v1/"

const api_config =
{ 
    API_URL, TIMEOUT, BACKEND
};

export default api_config;