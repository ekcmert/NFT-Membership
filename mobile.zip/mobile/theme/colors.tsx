export default {
	primary: "rgb(0, 122, 255)",
	white: "#fff",
	black: "#000",
	medium: "#ccc",
	light: "#eee",
	online: "green",
	grey: "gray",
	red: "red",
	purple: "purple",
	orange: "#FF4301",
	cyan: "#5865F2"
}

