export const categoriesWithIcons = [
    {
        title: "Art",
        icon: 'deviantart',
        id: "3123432341"
    },
    {
        title: "Sport",
        icon: 'soccer-ball-o',
        id: "3123432342"
    },
    {
        title: "Collectible",
        icon: "empire",
        id: "3123432343"
    },
    {
        title: "Gif",
        icon: "rocket",
        id: "3123432344"
    },
    {
        title: "Photography",
        icon: "camera-retro",
        id: "3123432345"
    }
];